package com.smit.finalproject.model

data class Restaurant(
    val resId: Int,
    val resName: String,
    val resRating: String,
    val resCostForOne: String,
    val resImage: String
)
